import 'package:flutter/material.dart';
import 'package:deliverjoy_flutter/app/app.dart';

void main() => runApp(const MyApp());
