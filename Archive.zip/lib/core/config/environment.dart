enum Environment {
  development,
  production,
}

class AppConfig {
  static const Environment _environment = Environment.development;
  
  static Environment get environment => _environment;
  
  static String get baseUrl {
    switch (_environment) {
      case Environment.development:
        return 'https://api-dev.deliverjoy.com';
      case Environment.production:
        return 'https://api.deliverjoy.com';
    }
  }
  
  static String get appName {
    switch (_environment) {
      case Environment.development:
        return 'DeliverJoy Dev';
      case Environment.production:
        return 'DeliverJoy';
    }
  }
  
  static bool get isDebug {
    return _environment == Environment.development;
  }
}
