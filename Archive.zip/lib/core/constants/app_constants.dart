class AppConstants {
  static const defaultUserName = 'Shahzaib';
}


