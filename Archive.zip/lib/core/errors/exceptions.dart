import 'package:dio/dio.dart';
import 'package:deliverjoy_flutter/core/errors/failures.dart';

class ServerException implements Exception {
  final String message;
  final int? statusCode;
  
  const ServerException(this.message, [this.statusCode]);
}

class NetworkException implements Exception {
  final String message;
  
  const NetworkException(this.message);
}

class CacheException implements Exception {
  final String message;
  
  const CacheException(this.message);
}

class ValidationException implements Exception {
  final String message;
  final Map<String, List<String>>? errors;
  
  const ValidationException(this.message, [this.errors]);
}

class UnknownException implements Exception {
  final String message;
  
  const UnknownException(this.message);
}

extension DioExceptionExtension on DioException {
  Failure toFailure() {
    switch (type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return const Failure.network(message: 'Connection timeout');
      case DioExceptionType.badResponse:
        final statusCode = response?.statusCode;
        final message = response?.data?['message'] ?? 'Server error';
        return Failure.server(message: message, statusCode: statusCode);
      case DioExceptionType.cancel:
        return const Failure.network(message: 'Request cancelled');
      case DioExceptionType.connectionError:
        return const Failure.network(message: 'No internet connection');
      case DioExceptionType.badCertificate:
        return const Failure.network(message: 'Certificate error');
      case DioExceptionType.unknown:
        return Failure.unknown(message: message ?? 'Unknown error occurred');
    }
  }
}
