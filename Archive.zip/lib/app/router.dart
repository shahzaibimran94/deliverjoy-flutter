import 'package:deliverjoy_flutter/features/basket/presentation/basket_screen.dart';
import 'package:deliverjoy_flutter/features/home/presentation/home_screen.dart';
import 'package:deliverjoy_flutter/features/orders/presentation/orders_screen.dart';
import 'package:deliverjoy_flutter/features/shell/presentation/shell.dart';
import 'package:deliverjoy_flutter/features/search_chat/presentation/chat_screen.dart';
import 'package:deliverjoy_flutter/features/payment/presentation/payment_screen.dart';
import 'package:deliverjoy_flutter/features/payment/presentation/payment_success_screen.dart';
import 'package:deliverjoy_flutter/features/products/presentation/products_screen.dart';
import 'package:deliverjoy_flutter/features/auth/presentation/login_screen.dart';
import 'package:deliverjoy_flutter/features/auth/presentation/signup_screen.dart';
import 'package:deliverjoy_flutter/features/auth/presentation/forgot_password_screen.dart';
import 'package:deliverjoy_flutter/features/auth/presentation/auth_guard.dart';
import 'package:deliverjoy_flutter/features/profile/presentation/profile_screen.dart';
import 'package:deliverjoy_flutter/features/onboarding/presentation/onboarding_screen.dart';
import 'package:deliverjoy_flutter/features/onboarding/presentation/onboarding_guard.dart';
import 'package:deliverjoy_flutter/features/home/presentation/home_guard.dart';
import 'package:deliverjoy_flutter/features/subscription/presentation/subscription_screen.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

final GlobalKey<NavigatorState> _rootKey = GlobalKey<NavigatorState>(debugLabel: 'root');

final GoRouter appRouter = GoRouter(
  navigatorKey: _rootKey,
  initialLocation: '/login',
  routes: [
    // Authentication routes (guest only)
    GoRoute(
      path: '/login',
      name: 'login',
      builder: (context, state) => const GuestGuard(child: LoginScreen()),
    ),
    GoRoute(
      path: '/signup',
      name: 'signup',
      builder: (context, state) => const GuestGuard(child: SignUpScreen()),
    ),
    GoRoute(
      path: '/forgot-password',
      name: 'forgot-password',
      builder: (context, state) => const GuestGuard(child: ForgotPasswordScreen()),
    ),
    
    // Onboarding route (outside shell to avoid bottom navigation)
    GoRoute(
      path: '/onboarding',
      name: 'onboarding',
      builder: (context, state) => const OnboardingGuard(child: OnboardingScreen()),
    ),
    
    // Protected routes
    StatefulShellRoute.indexedStack(
      builder: (context, state, navigationShell) => AuthGuard(child: RootScaffoldShell(navigationShell: navigationShell)),
      branches: [
        StatefulShellBranch(routes: [
          GoRoute(path: '/home', name: 'home', builder: (context, state) => const HomeGuard(child: HomeScreen())),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(path: '/orders', name: 'orders', builder: (context, state) => const AuthGuard(child: OrdersScreen())),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(path: '/basket', name: 'basket', builder: (context, state) => const AuthGuard(child: BasketScreen())),
        ]),
      ],
    ),
    GoRoute(
      path: '/chat', 
      name: 'chat', 
      builder: (context, state) => AuthGuard(child: ChatSearchScreen(initialQuery: state.extra as String?)),
    ),
    GoRoute(
      path: '/payment',
      name: 'payment',
      builder: (context, state) => const AuthGuard(child: PaymentScreen()),
    ),
    GoRoute(
      path: '/payment-success',
      name: 'payment-success',
      builder: (context, state) => const AuthGuard(child: PaymentSuccessScreen()),
    ),
    GoRoute(
      path: '/products',
      name: 'products',
      builder: (context, state) => const AuthGuard(child: ProductsScreen()),
    ),
    GoRoute(
      path: '/profile',
      name: 'profile',
      builder: (context, state) => const AuthGuard(child: ProfileScreen()),
    ),
    GoRoute(
      path: '/subscription',
      name: 'subscription',
      builder: (context, state) => const AuthGuard(child: SubscriptionScreen(isFromOnboarding: false)),
    ),
      ],
    );
