import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static ThemeData light() {
    final Color seed = const Color(0xFF7F56D9);
    return ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: seed),
      textTheme: GoogleFonts.interTextTheme(),
      useMaterial3: true,
    );
  }
}


