import 'package:flutter/material.dart';
import 'package:deliverjoy_flutter/app/theme.dart';
import 'package:deliverjoy_flutter/app/router.dart';
import 'package:deliverjoy_flutter/core/config/environment.dart';
import 'package:deliverjoy_flutter/core/network/api_client.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Initialize API client
    ApiClient().initialize();
    
    return ProviderScope(
      child: MaterialApp.router(
        title: AppConfig.appName,
        theme: AppTheme.light(),
        routerConfig: appRouter,
        debugShowCheckedModeBanner: AppConfig.isDebug,
      ),
    );
  }
}


