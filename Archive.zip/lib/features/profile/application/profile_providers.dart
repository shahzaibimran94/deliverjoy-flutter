import 'package:flutter_riverpod/flutter_riverpod.dart';

// User profile data
final userProfileProvider = StateProvider.autoDispose<UserProfile>((ref) => UserProfile(
  name: 'John Doe',
  email: 'john@example.com',
  dateOfBirth: DateTime(1990, 5, 15),
  gender: Gender.male,
  phoneNumber: '+92 300 1234567',
  avatarUrl: null,
));

// Family members
final familyMembersProvider = StateProvider.autoDispose<List<FamilyMember>>((ref) => [
  FamilyMember(
    id: '1',
    name: 'Sarah Doe',
    relation: 'Sister',
    dateOfBirth: DateTime(1995, 8, 20),
  ),
  FamilyMember(
    id: '2',
    name: 'Michael Doe',
    relation: 'Brother',
    dateOfBirth: DateTime(1988, 3, 10),
  ),
]);

// Addresses
final addressesProvider = StateProvider.autoDispose<List<Address>>((ref) => [
  Address(
    id: '1',
    label: 'Home',
    address: '123 Main Street, Block A, DHA Phase 2',
    city: 'Karachi',
    province: 'Sindh',
    postalCode: '75500',
    isDefault: true,
  ),
  Address(
    id: '2',
    label: 'Office',
    address: '456 Business District, Gulberg',
    city: 'Lahore',
    province: 'Punjab',
    postalCode: '54000',
    isDefault: false,
  ),
]);

// Order recipients
final orderRecipientsProvider = StateProvider.autoDispose<List<OrderRecipient>>((ref) => [
  OrderRecipient(
    id: '1',
    name: 'Sarah Ahmed',
    phoneNumber: '+92 300 1234567',
    isDefault: true,
  ),
  OrderRecipient(
    id: '2',
    name: 'Ali Khan',
    phoneNumber: '+92 301 9876543',
    isDefault: false,
  ),
]);

// Referral data
final referralDataProvider = StateProvider.autoDispose<ReferralData>((ref) => ReferralData(
  referralCode: 'DELIVER2024',
  totalReferrals: 3,
  usedReferrals: 2,
  rewards: [
    ReferralReward(
      referralsNeeded: 1,
      reward: '1 Free Delivery',
      isUnlocked: true,
    ),
    ReferralReward(
      referralsNeeded: 5,
      reward: '10% Discount on Next Order',
      isUnlocked: false,
    ),
    ReferralReward(
      referralsNeeded: 10,
      reward: 'Premium Gift Box',
      isUnlocked: false,
    ),
  ],
));

// Data models
class UserProfile {
  final String name;
  final String email;
  final DateTime dateOfBirth;
  final Gender gender;
  final String phoneNumber;
  final String? avatarUrl;

  const UserProfile({
    required this.name,
    required this.email,
    required this.dateOfBirth,
    required this.gender,
    required this.phoneNumber,
    this.avatarUrl,
  });

  UserProfile copyWith({
    String? name,
    String? email,
    DateTime? dateOfBirth,
    Gender? gender,
    String? phoneNumber,
    String? avatarUrl,
  }) {
    return UserProfile(
      name: name ?? this.name,
      email: email ?? this.email,
      dateOfBirth: dateOfBirth ?? this.dateOfBirth,
      gender: gender ?? this.gender,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      avatarUrl: avatarUrl ?? this.avatarUrl,
    );
  }
}

class FamilyMember {
  final String id;
  final String name;
  final String relation;
  final DateTime dateOfBirth;

  const FamilyMember({
    required this.id,
    required this.name,
    required this.relation,
    required this.dateOfBirth,
  });
}

class OrderRecipient {
  final String id;
  final String name;
  final String phoneNumber;
  final bool isDefault;

  const OrderRecipient({
    required this.id,
    required this.name,
    required this.phoneNumber,
    required this.isDefault,
  });
}

class Address {
  final String id;
  final String label;
  final String address;
  final String city;
  final String province;
  final String postalCode;
  final bool isDefault;

  const Address({
    required this.id,
    required this.label,
    required this.address,
    required this.city,
    required this.province,
    required this.postalCode,
    required this.isDefault,
  });
}

class ReferralData {
  final String referralCode;
  final int totalReferrals;
  final int usedReferrals;
  final List<ReferralReward> rewards;

  const ReferralData({
    required this.referralCode,
    required this.totalReferrals,
    required this.usedReferrals,
    required this.rewards,
  });
}

class ReferralReward {
  final int referralsNeeded;
  final String reward;
  final bool isUnlocked;

  const ReferralReward({
    required this.referralsNeeded,
    required this.reward,
    required this.isUnlocked,
  });
}

enum Gender { male, female, other }
