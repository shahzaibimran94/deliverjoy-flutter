import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../application/profile_providers.dart';
import '../../auth/application/auth_providers.dart';
import '../../subscription/application/subscription_providers.dart';
import '../../subscription/presentation/subscription_screen.dart';
import 'widgets/update_profile_modal.dart';
import 'widgets/family_members_drawer.dart';
import 'widgets/order_recipients_drawer.dart';
import 'widgets/addresses_drawer.dart';
import 'widgets/referral_drawer.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userProfile = ref.watch(userProfileProvider);
    final familyMembers = ref.watch(familyMembersProvider);
    final addresses = ref.watch(addressesProvider);
    final orderRecipients = ref.watch(orderRecipientsProvider);
    final referralData = ref.watch(referralDataProvider);
    final userSubscription = ref.watch(userSubscriptionProvider);
    final isProMember = ref.watch(isProMemberProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        backgroundColor: Theme.of(context).colorScheme.surface,
        elevation: 0,
        actions: [
          IconButton(
            onPressed: () => _showLogoutDialog(context, ref),
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Profile Header
            _buildProfileHeader(context, userProfile),
            
            const SizedBox(height: 24),
            
            // Profile Actions
            _buildActionCard(
              context,
              'Personal Information',
              'Update your personal details',
              Icons.person,
              () => _showUpdateProfileModal(context, ref),
            ),
            
            const SizedBox(height: 12),
            
            _buildActionCard(
              context,
              'Family Members',
              '${familyMembers.length} family members',
              Icons.family_restroom,
              () => _showFamilyMembersDrawer(context, ref),
            ),
            
            const SizedBox(height: 12),
            
            _buildActionCard(
              context,
              'Order Recipients',
              '${orderRecipients.length} recipients',
              Icons.person_add,
              () => _showOrderRecipientsDrawer(context, ref),
            ),
            
            const SizedBox(height: 12),
            
            _buildActionCard(
              context,
              'Delivery Addresses',
              '${addresses.length} addresses in Pakistan',
              Icons.location_on,
              () => _showAddressesDrawer(context, ref),
            ),
            
            const SizedBox(height: 12),
            
            _buildActionCard(
              context,
              'Referral Program',
              '${referralData.usedReferrals}/${referralData.totalReferrals} referrals used',
              Icons.share,
              () => _showReferralDrawer(context, ref),
            ),
            
            const SizedBox(height: 12),
            
            _buildActionCard(
              context,
              'Subscription',
              isProMember ? 'Pro Member - Premium features' : 'Free Plan - Upgrade to Pro',
              isProMember ? Icons.star : Icons.upgrade,
              () => _showSubscriptionScreen(context),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileHeader(BuildContext context, UserProfile profile) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 40,
            backgroundColor: Theme.of(context).colorScheme.primary,
            backgroundImage: profile.avatarUrl != null 
                ? NetworkImage(profile.avatarUrl!) 
                : null,
            child: profile.avatarUrl == null 
                ? Text(
                    profile.name.isNotEmpty ? profile.name[0].toUpperCase() : 'U',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  )
                : null,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  profile.name,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  profile.email,
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  profile.phoneNumber,
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionCard(
    BuildContext context,
    String title,
    String subtitle,
    IconData icon,
    VoidCallback onTap,
  ) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Colors.grey[200]!),
      ),
      child: ListTile(
        leading: Icon(icon, color: Theme.of(context).colorScheme.primary),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: onTap,
      ),
    );
  }

  void _showLogoutDialog(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sign Out'),
        content: const Text('Are you sure you want to sign out?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              signOut(ref);
              context.go('/login');
            },
            child: const Text('Sign Out'),
          ),
        ],
      ),
    );
  }

  void _showUpdateProfileModal(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => const UpdateProfileModal(),
    );
  }

  void _showFamilyMembersDrawer(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => const FamilyMembersDrawer(),
    );
  }

  void _showOrderRecipientsDrawer(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => const OrderRecipientsDrawer(),
    );
  }

  void _showAddressesDrawer(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => const AddressesDrawer(),
    );
  }

  void _showReferralDrawer(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => const ReferralDrawer(),
    );
  }

  void _showSubscriptionScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const SubscriptionScreen(isFromOnboarding: false),
      ),
    );
  }
}
