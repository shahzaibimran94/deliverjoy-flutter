import 'package:flutter_riverpod/flutter_riverpod.dart';

// Search state
final searchQueryProvider = StateProvider.autoDispose<String>((ref) => '');
final searchResultsProvider = StateProvider.autoDispose<List<SearchResult>>((ref) => []);
final isSearchingProvider = StateProvider.autoDispose<bool>((ref) => false);

// Chat messages
final chatMessagesProvider = StateProvider.autoDispose<List<ChatMessage>>((ref) => [
  ChatMessage(
    role: ChatRole.system,
    text: 'Hi! Search for a gift or paste a product link. We\'ll create a custom order for anything you want!',
  ),
]);

// Custom order state
final customOrderProvider = StateProvider.autoDispose<CustomOrder?>((ref) => null);
final isCreatingOrderProvider = StateProvider.autoDispose<bool>((ref) => false);

// Search function
final searchProvider = FutureProvider.autoDispose.family<List<SearchResult>, String>((ref, query) async {
  if (query.trim().isEmpty) return [];
  
  // Simulate search delay
  await Future.delayed(const Duration(milliseconds: 800));
  
  // Mock search results - in real app, this would call an API
  return _getMockSearchResults(query);
});

List<SearchResult> _getMockSearchResults(String query) {
  final allResults = [
    SearchResult(
      id: '1',
      title: 'Mother\'s Day Gift Box',
      description: 'Beautiful gift box with flowers and chocolates',
      price: 49.99,
      imageUrl: 'https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=300',
    ),
    SearchResult(
      id: '2',
      title: 'Valentine\'s Day Special',
      description: 'Romantic gift set with roses and wine',
      price: 79.99,
      imageUrl: 'https://images.unsplash.com/photo-1518199266791-5375a83190b7?w=300',
    ),
    SearchResult(
      id: '3',
      title: 'Father\'s Day Tools',
      description: 'Premium tool set for dad',
      price: 129.99,
      imageUrl: 'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=300',
    ),
  ];
  
  // Simple search logic - in real app, this would be more sophisticated
  return allResults.where((result) => 
    result.title.toLowerCase().contains(query.toLowerCase()) ||
    result.description.toLowerCase().contains(query.toLowerCase())
  ).toList();
}

// Create custom order
final createCustomOrderProvider = FutureProvider.autoDispose.family<CustomOrder, String>((ref, link) async {
  // Simulate order creation delay
  await Future.delayed(const Duration(milliseconds: 1500));
  
  // Mock order creation
  final order = CustomOrder(
    id: 'CUSTOM_${DateTime.now().millisecondsSinceEpoch}',
    requestedItem: link,
    estimatedPrice: 99.99, // In real app, this would be calculated
    paymentLink: 'https://payment.example.com/pay/${DateTime.now().millisecondsSinceEpoch}',
    status: OrderStatus.pending,
    createdAt: DateTime.now(),
  );
  
  return order;
});

// Data models
class SearchResult {
  final String id;
  final String title;
  final String description;
  final double price;
  final String imageUrl;
  
  const SearchResult({
    required this.id,
    required this.title,
    required this.description,
    required this.price,
    required this.imageUrl,
  });
}

class ChatMessage {
  final ChatRole role;
  final String text;
  final bool isLink;
  final DateTime timestamp;
  
  ChatMessage({
    required this.role,
    required this.text,
    this.isLink = false,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime(2024, 1, 1);
}

enum ChatRole { system, user, assistant }

class CustomOrder {
  final String id;
  final String requestedItem;
  final double estimatedPrice;
  final String paymentLink;
  final OrderStatus status;
  final DateTime createdAt;
  
  const CustomOrder({
    required this.id,
    required this.requestedItem,
    required this.estimatedPrice,
    required this.paymentLink,
    required this.status,
    required this.createdAt,
  });
}

enum OrderStatus { pending, paid, processing, shipped, delivered }
