import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import '../application/search_providers.dart';

class ChatSearchScreen extends ConsumerStatefulWidget {
  final String? initialQuery;
  
  const ChatSearchScreen({super.key, this.initialQuery});

  @override
  ConsumerState<ChatSearchScreen> createState() => _ChatSearchScreenState();
}

class _ChatSearchScreenState extends ConsumerState<ChatSearchScreen> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    if (widget.initialQuery != null) {
      _controller.text = widget.initialQuery!;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _performSearch(widget.initialQuery!);
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _performSearch(String query) async {
    if (query.trim().isEmpty) return;
    
    // Add user message
    final messages = [...ref.read(chatMessagesProvider)];
    messages.add(ChatMessage(role: ChatRole.user, text: query));
    ref.read(chatMessagesProvider.notifier).state = messages;
    _scrollToBottom();

    // Set loading state
    ref.read(isSearchingProvider.notifier).state = true;

    // Perform search
    ref.read(searchQueryProvider.notifier).state = query;
    final searchResults = await ref.read(searchProvider(query).future);
    
    // Clear loading state
    ref.read(isSearchingProvider.notifier).state = false;
    
    // Add response message
    final updatedMessages = [...ref.read(chatMessagesProvider)];
    if (searchResults.isEmpty) {
      updatedMessages.add(ChatMessage(
        role: ChatRole.assistant,
        text: 'No results found for "$query". Let\'s create a custom order! Send me a link to what you want and I\'ll pack it for you.',
      ));
    } else {
      final resultText = searchResults.map((r) => '• ${r.title} - \$${r.price.toStringAsFixed(2)}').join('\n');
      updatedMessages.add(ChatMessage(
        role: ChatRole.assistant,
        text: 'Found ${searchResults.length} results:\n\n$resultText\n\nWould you like to order any of these, or send a custom link?',
      ));
    }
    ref.read(chatMessagesProvider.notifier).state = updatedMessages;
    _scrollToBottom();
  }

  void _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;

    _controller.clear();
    
    // Add user message
    final messages = [...ref.read(chatMessagesProvider)];
    messages.add(ChatMessage(role: ChatRole.user, text: text));
    ref.read(chatMessagesProvider.notifier).state = messages;
    _scrollToBottom();
    
    // Check if it's a URL for custom order
    final bool isUrl = Uri.tryParse(text)?.hasAbsolutePath == true || text.startsWith('http');
    
    if (isUrl) {
      // Set loading state for custom order
      ref.read(isCreatingOrderProvider.notifier).state = true;
      
      // Create custom order
      final order = await ref.read(createCustomOrderProvider(text).future);
      
      // Clear loading state
      ref.read(isCreatingOrderProvider.notifier).state = false;
      
      // Store the order
      ref.read(customOrderProvider.notifier).state = order;
      
      // Add order confirmation to chat
      final updatedMessages = [...ref.read(chatMessagesProvider)];
      updatedMessages.add(ChatMessage(
        role: ChatRole.assistant,
        text: 'Custom order created! Here are the details:\n\n'
              'Order ID: ${order.id}\n'
              'Requested Item: ${order.requestedItem}\n'
              'Estimated Price: \$${order.estimatedPrice.toStringAsFixed(2)}\n\n'
              'Click the payment link below to complete your order:',
      ));
      updatedMessages.add(ChatMessage(
        role: ChatRole.assistant,
        text: order.paymentLink,
        isLink: true,
      ));
      ref.read(chatMessagesProvider.notifier).state = updatedMessages;
    } else {
      // Perform search
      _performSearch(text);
    }
    
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final messages = ref.watch(chatMessagesProvider);
    final isSearching = ref.watch(isSearchingProvider);
    final isCreatingOrder = ref.watch(isCreatingOrderProvider);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Search & Chat'),
        backgroundColor: Theme.of(context).colorScheme.surface,
        elevation: 0,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
              itemCount: messages.length + (isSearching || isCreatingOrder ? 1 : 0),
              itemBuilder: (context, index) {
                if (index == messages.length && (isSearching || isCreatingOrder)) {
                  return _buildLoadingMessage(isCreatingOrder ? 'Creating custom order...' : 'Searching...');
                }
                
                final message = messages[index];
                return _buildMessage(message);
              },
            ),
          ),
          _buildInputField(),
        ],
      ),
    );
  }

  Widget _buildMessage(ChatMessage message) {
    final isUser = message.role == ChatRole.user;
    final isSystem = message.role == ChatRole.system;
    final align = isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start;
    final bg = isSystem
        ? Theme.of(context).colorScheme.surfaceContainerHighest
        : isUser
            ? Theme.of(context).colorScheme.primary
            : Theme.of(context).colorScheme.surfaceContainerHigh;
    final fg = isUser ? Colors.white : Theme.of(context).colorScheme.onSurface;
    
    return Column(
      crossAxisAlignment: align,
      children: [
        Container(
          margin: const EdgeInsets.symmetric(vertical: 6),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(12),
          ),
          child: message.isLink
              ? _buildLinkMessage(message.text)
              : Text(message.text, style: TextStyle(color: fg)),
        ),
      ],
    );
  }

  Widget _buildLinkMessage(String link) {
    return GestureDetector(
      onTap: () async {
        final uri = Uri.parse(link);
        if (await canLaunchUrl(uri)) {
          await launchUrl(uri, mode: LaunchMode.externalApplication);
        }
      },
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.blue.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.blue.withValues(alpha: 0.3)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.payment, color: Colors.blue, size: 16),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                link,
                style: const TextStyle(
                  color: Colors.blue,
                  decoration: TextDecoration.underline,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingMessage(String text) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHigh,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 16,
            height: 16,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const SizedBox(width: 12),
          Text(text, style: TextStyle(color: Theme.of(context).colorScheme.onSurface)),
        ],
      ),
    );
  }

  Widget _buildInputField() {
    final isSearching = ref.watch(isSearchingProvider);
    final isCreatingOrder = ref.watch(isCreatingOrderProvider);
    final isLoading = isSearching || isCreatingOrder;
    
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 6, 12, 12),
        child: Row(
          children: [
            Expanded(
              child: TextField(
                controller: _controller,
                enabled: !isLoading,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _send(),
                decoration: InputDecoration(
                  hintText: isLoading 
                      ? (isCreatingOrder ? 'Creating order...' : 'Searching...')
                      : 'Search gifts or paste a product link',
                  filled: true,
                  fillColor: isLoading ? Colors.grey[200] : Colors.grey[100],
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                ),
              ),
            ),
            const SizedBox(width: 8),
            IconButton(
              onPressed: isLoading ? null : _send,
              style: IconButton.styleFrom(
                backgroundColor: isLoading 
                    ? Colors.grey[300] 
                    : Theme.of(context).colorScheme.primary,
                foregroundColor: Colors.white,
              ),
              icon: isLoading
                  ? const SizedBox(
                      width: 18, 
                      height: 18, 
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.send),
            ),
          ],
        ),
      ),
    );
  }
}