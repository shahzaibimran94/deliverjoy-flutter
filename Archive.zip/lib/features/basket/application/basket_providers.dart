import 'package:flutter_riverpod/flutter_riverpod.dart';

// Basket state
final basketItemsProvider = StateProvider.autoDispose<List<BasketItem>>((ref) => []);
final basketTotalProvider = Provider.autoDispose<double>((ref) {
  final items = ref.watch(basketItemsProvider);
  return items.fold(0.0, (total, item) => total + (item.price * item.quantity));
});

// Delivery and fees
final deliveryFeeProvider = StateProvider.autoDispose<double>((ref) => 4.99);
final serviceFeeProvider = StateProvider.autoDispose<double>((ref) => 2.99);
final taxProvider = Provider.autoDispose<double>((ref) {
  final subtotal = ref.watch(basketTotalProvider);
  return subtotal * 0.08; // 8% tax
});

final promoDiscountProvider = Provider.autoDispose<double>((ref) {
  final appliedPromo = ref.watch(appliedPromoCodeProvider);
  if (appliedPromo == null) return 0.0;
  
  final subtotal = ref.watch(basketTotalProvider);
  if (appliedPromo.isPercentage) {
    return subtotal * (appliedPromo.discountAmount / 100);
  } else {
    return appliedPromo.discountAmount;
  }
});

final grandTotalProvider = Provider.autoDispose<double>((ref) {
  final subtotal = ref.watch(basketTotalProvider);
  final delivery = ref.watch(deliveryFeeProvider);
  final service = ref.watch(serviceFeeProvider);
  final tax = ref.watch(taxProvider);
  final promoDiscount = ref.watch(promoDiscountProvider);
  
  final total = subtotal + delivery + service + tax - promoDiscount;
  return total < 0 ? 0 : total; // Ensure total doesn't go negative
});

// Payment state
final paymentMethodProvider = StateProvider.autoDispose<PaymentMethod>((ref) => PaymentMethod.card);
final isProcessingPaymentProvider = StateProvider.autoDispose<bool>((ref) => false);

// Promo code state
final appliedPromoCodeProvider = StateProvider.autoDispose<PromoCode?>((ref) => null);
final isApplyingPromoProvider = StateProvider.autoDispose<bool>((ref) => false);

// Add item to basket
void addToBasket(WidgetRef ref, Product product) {
  final items = ref.read(basketItemsProvider);
  final existingIndex = items.indexWhere((item) => item.productId == product.id);
  
  if (existingIndex != -1) {
    // Update quantity
    final updatedItems = [...items];
    updatedItems[existingIndex] = updatedItems[existingIndex].copyWith(
      quantity: updatedItems[existingIndex].quantity + 1,
    );
    ref.read(basketItemsProvider.notifier).state = updatedItems;
  } else {
    // Add new item
    final newItem = BasketItem(
      productId: product.id,
      name: product.name,
      price: product.price,
      imageUrl: product.imageUrl,
      quantity: 1,
    );
    ref.read(basketItemsProvider.notifier).state = [...items, newItem];
  }
}

// Update item quantity
void updateItemQuantity(WidgetRef ref, String productId, int quantity) {
  if (quantity <= 0) {
    removeFromBasket(ref, productId);
    return;
  }
  
  final items = ref.read(basketItemsProvider);
  final updatedItems = items.map((item) {
    if (item.productId == productId) {
      return item.copyWith(quantity: quantity);
    }
    return item;
  }).toList();
  
  ref.read(basketItemsProvider.notifier).state = updatedItems;
}

// Remove item from basket
void removeFromBasket(WidgetRef ref, String productId) {
  final items = ref.read(basketItemsProvider);
  final updatedItems = items.where((item) => item.productId != productId).toList();
  ref.read(basketItemsProvider.notifier).state = updatedItems;
}

// Clear basket
void clearBasket(WidgetRef ref) {
  ref.read(basketItemsProvider.notifier).state = [];
}

// Apply promo code
Future<void> applyPromoCode(WidgetRef ref, String code) async {
  ref.read(isApplyingPromoProvider.notifier).state = true;
  
  // Simulate API call
  await Future.delayed(const Duration(milliseconds: 1000));
  
  // Mock promo codes
  final promoCode = _getPromoCode(code);
  
  ref.read(isApplyingPromoProvider.notifier).state = false;
  
  if (promoCode != null) {
    ref.read(appliedPromoCodeProvider.notifier).state = promoCode;
  }
}

// Remove promo code
void removePromoCode(WidgetRef ref) {
  ref.read(appliedPromoCodeProvider.notifier).state = null;
}

// Mock promo code validation
PromoCode? _getPromoCode(String code) {
  final promoCodes = {
    'SAVE10': PromoCode(code: 'SAVE10', discountAmount: 10.0, isPercentage: false, description: 'Save \$10'),
    'WELCOME20': PromoCode(code: 'WELCOME20', discountAmount: 20.0, isPercentage: true, description: '20% off for new customers'),
    'FREESHIP': PromoCode(code: 'FREESHIP', discountAmount: 4.99, isPercentage: false, description: 'Free delivery'),
    'HOLIDAY15': PromoCode(code: 'HOLIDAY15', discountAmount: 15.0, isPercentage: true, description: '15% holiday discount'),
  };
  
  return promoCodes[code];
}

// Process payment
Future<bool> processPayment(WidgetRef ref) async {
  ref.read(isProcessingPaymentProvider.notifier).state = true;
  
  // Simulate payment processing
  await Future.delayed(const Duration(seconds: 3));
  
  ref.read(isProcessingPaymentProvider.notifier).state = false;
  
  // In a real app, this would call a payment API
  return true; // Simulate successful payment
}

// Data models
class BasketItem {
  final String productId;
  final String name;
  final double price;
  final String imageUrl;
  final int quantity;

  const BasketItem({
    required this.productId,
    required this.name,
    required this.price,
    required this.imageUrl,
    required this.quantity,
  });

  BasketItem copyWith({
    String? productId,
    String? name,
    double? price,
    String? imageUrl,
    int? quantity,
  }) {
    return BasketItem(
      productId: productId ?? this.productId,
      name: name ?? this.name,
      price: price ?? this.price,
      imageUrl: imageUrl ?? this.imageUrl,
      quantity: quantity ?? this.quantity,
    );
  }

  double get totalPrice => price * quantity;
}

class Product {
  final String id;
  final String name;
  final double price;
  final String imageUrl;
  final String? description;

  const Product({
    required this.id,
    required this.name,
    required this.price,
    required this.imageUrl,
    this.description,
  });
}

enum PaymentMethod {
  card,
  applePay,
  googlePay,
  paypal,
}

extension PaymentMethodExtension on PaymentMethod {
  String get displayName {
    switch (this) {
      case PaymentMethod.card:
        return 'Credit/Debit Card';
      case PaymentMethod.applePay:
        return 'Apple Pay';
      case PaymentMethod.googlePay:
        return 'Google Pay';
      case PaymentMethod.paypal:
        return 'PayPal';
    }
  }

  String get icon {
    switch (this) {
      case PaymentMethod.card:
        return '💳';
      case PaymentMethod.applePay:
        return '🍎';
      case PaymentMethod.googlePay:
        return 'G';
      case PaymentMethod.paypal:
        return 'P';
    }
  }
}

class PromoCode {
  final String code;
  final double discountAmount;
  final bool isPercentage;
  final String description;

  const PromoCode({
    required this.code,
    required this.discountAmount,
    required this.isPercentage,
    required this.description,
  });
}
