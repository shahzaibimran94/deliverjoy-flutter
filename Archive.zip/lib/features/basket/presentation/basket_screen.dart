import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../application/basket_providers.dart';
import 'widgets/basket_item_card.dart';
import 'widgets/order_summary.dart';
import 'widgets/empty_basket_state.dart';
import 'widgets/promo_code_section.dart';
import 'widgets/delivery_selection.dart';

class BasketScreen extends ConsumerWidget {
  const BasketScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final basketItems = ref.watch(basketItemsProvider);
    final grandTotal = ref.watch(grandTotalProvider);

    if (basketItems.isEmpty) {
      return const Scaffold(
        appBar: null,
        body: EmptyBasketState(),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Basket'),
        backgroundColor: Theme.of(context).colorScheme.surface,
        elevation: 0,
        actions: [
          TextButton(
            onPressed: () => _clearBasket(ref),
            child: Text(
              'Clear All',
              style: TextStyle(
                color: Colors.red[600],
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          // Scrollable Content
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  // Basket Items
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    itemCount: basketItems.length,
                    itemBuilder: (context, index) {
                      final item = basketItems[index];
                      return BasketItemCard(item: item);
                    },
                  ),
                  // Delivery and Payment Sections
                  const DeliverySelection(),
                  const PromoCodeSection(),
                  OrderSummary(),
                ],
              ),
            ),
          ),
          // Fixed Checkout Button
          _buildCheckoutButton(context, ref, grandTotal),
        ],
      ),
    );
  }

  Widget _buildCheckoutButton(BuildContext context, WidgetRef ref, double total) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: () => _navigateToPayment(context),
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.primary,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.payment, size: 20),
                const SizedBox(width: 8),
                Text(
                  'Checkout • \$${total.toStringAsFixed(2)}',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _clearBasket(WidgetRef ref) {
    clearBasket(ref);
  }

  void _navigateToPayment(BuildContext context) {
    context.push('/payment');
  }
}


