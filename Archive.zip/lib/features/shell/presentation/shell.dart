import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../basket/application/basket_providers.dart';

class RootScaffoldShell extends ConsumerWidget {
  final StatefulNavigationShell navigationShell;
  const RootScaffoldShell({super.key, required this.navigationShell});

  void _onTap(int index) {
    navigationShell.goBranch(index,
        initialLocation: index == navigationShell.currentIndex);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final basketItems = ref.watch(basketItemsProvider);
    final itemCount = basketItems.fold(0, (total, item) => total + item.quantity);

    return Scaffold(
      body: navigationShell,
      bottomNavigationBar: NavigationBar(
        selectedIndex: navigationShell.currentIndex,
        destinations: [
          const NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Home'
          ),
          const NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            selectedIcon: Icon(Icons.receipt_long),
            label: 'Orders'
          ),
          NavigationDestination(
            icon: _buildBasketIcon(itemCount),
            selectedIcon: _buildBasketIcon(itemCount, isSelected: true),
            label: 'Basket',
          ),
        ],
        onDestinationSelected: _onTap,
      ),
    );
  }

  Widget _buildBasketIcon(int itemCount, {bool isSelected = false}) {
    if (itemCount == 0) {
      return Icon(
        isSelected ? Icons.shopping_basket : Icons.shopping_basket_outlined,
      );
    }

    return Stack(
      children: [
        Icon(
          isSelected ? Icons.shopping_basket : Icons.shopping_basket_outlined,
        ),
        Positioned(
          right: 0,
          top: 0,
          child: Container(
            padding: const EdgeInsets.all(2),
            decoration: BoxDecoration(
              color: Colors.red,
              borderRadius: BorderRadius.circular(10),
            ),
            constraints: const BoxConstraints(
              minWidth: 16,
              minHeight: 16,
            ),
            child: Text(
              itemCount > 99 ? '99+' : itemCount.toString(),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 10,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ),
      ],
    );
  }
}


