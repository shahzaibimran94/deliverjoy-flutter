import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../profile/application/profile_providers.dart';

// Onboarding step enum
enum OnboardingStep {
  familyMembers,
  orderRecipients,
  addresses,
}

// Onboarding state providers
final onboardingStepProvider = StateProvider.autoDispose<OnboardingStep>((ref) => OnboardingStep.familyMembers);

final onboardingCompletedProvider = StateProvider.autoDispose<bool>((ref) => false);

// Onboarding validation providers
final canProceedFromFamilyMembersProvider = Provider.autoDispose<bool>((ref) {
  final familyMembers = ref.watch(familyMembersProvider);
  return familyMembers.isNotEmpty;
});

final canProceedFromOrderRecipientsProvider = Provider.autoDispose<bool>((ref) {
  final orderRecipients = ref.watch(orderRecipientsProvider);
  return orderRecipients.isNotEmpty;
});

final canProceedFromAddressesProvider = Provider.autoDispose<bool>((ref) {
  final addresses = ref.watch(addressesProvider);
  return addresses.isNotEmpty;
});

// Onboarding completion function
void completeOnboarding(WidgetRef ref) {
  ref.read(onboardingCompletedProvider.notifier).state = true;
}
