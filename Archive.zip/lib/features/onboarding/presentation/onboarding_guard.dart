import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../auth/application/auth_providers.dart';

class OnboardingGuard extends ConsumerWidget {
  final Widget child;
  
  const OnboardingGuard({
    super.key,
    required this.child,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authStateProvider);
    final user = ref.watch(userProvider);
    final hasCompletedOnboarding = ref.watch(hasCompletedOnboardingProvider);
    
    // If user is authenticated, check onboarding status
    if (authState == AuthState.authenticated && user != null) {
      // If user hasn't completed onboarding, show onboarding
      if (!hasCompletedOnboarding) {
        return child;
      }
      
      // If user has completed onboarding, redirect to home
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (context.mounted) {
          context.go('/home');
        }
      });
      
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }
    
    // If not authenticated, redirect to login
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (context.mounted) {
        context.go('/login');
      }
    });
    
    // Show loading while redirecting
    return const Scaffold(
      body: Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}
