import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../application/onboarding_providers.dart';
import '../../profile/application/profile_providers.dart';
import '../../auth/application/auth_providers.dart';
import '../../subscription/presentation/subscription_screen.dart';
import 'widgets/progress_indicator.dart';
import 'widgets/family_members_step.dart';
import 'widgets/order_recipients_step.dart';
import 'widgets/addresses_step.dart';

class OnboardingScreen extends ConsumerWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentStep = ref.watch(onboardingStepProvider);
    final isCompleted = ref.watch(onboardingCompletedProvider);

    // If onboarding is completed, redirect to home
    if (isCompleted) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        context.go('/home');
      });
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            // Progress Indicator
            OnboardingProgressIndicator(currentStep: currentStep),
            
            // Step Content
            Expanded(
              child: _buildStepContent(context, ref, currentStep),
            ),
            
            // Navigation Buttons
            _buildNavigationButtons(context, ref, currentStep),
          ],
        ),
      ),
    );
  }

  Widget _buildStepContent(BuildContext context, WidgetRef ref, OnboardingStep step) {
    switch (step) {
      case OnboardingStep.familyMembers:
        return const FamilyMembersStep();
      case OnboardingStep.orderRecipients:
        return const OrderRecipientsStep();
      case OnboardingStep.addresses:
        return const AddressesStep();
    }
  }

  Widget _buildNavigationButtons(BuildContext context, WidgetRef ref, OnboardingStep currentStep) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        children: [
          // Back Button (only show if not on first step)
          if (currentStep != OnboardingStep.familyMembers)
            Expanded(
              child: OutlinedButton(
                onPressed: () => _goToPreviousStep(ref, currentStep),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text('Back'),
              ),
            ),
          
          if (currentStep != OnboardingStep.familyMembers)
            const SizedBox(width: 16),
          
          // Next/Complete Button
          Expanded(
            flex: 2,
            child: ElevatedButton(
              onPressed: () => _goToNextStep(context, ref, currentStep),
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.primary,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text(
                currentStep == OnboardingStep.addresses ? 'Complete Setup' : 'Next',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _goToPreviousStep(WidgetRef ref, OnboardingStep currentStep) {
    switch (currentStep) {
      case OnboardingStep.familyMembers:
        // Can't go back from first step
        break;
      case OnboardingStep.orderRecipients:
        ref.read(onboardingStepProvider.notifier).state = OnboardingStep.familyMembers;
        break;
      case OnboardingStep.addresses:
        ref.read(onboardingStepProvider.notifier).state = OnboardingStep.orderRecipients;
        break;
    }
  }

  void _goToNextStep(BuildContext context, WidgetRef ref, OnboardingStep currentStep) {
    switch (currentStep) {
      case OnboardingStep.familyMembers:
        // Validate family members step
        if (_validateFamilyMembersStep(ref)) {
          ref.read(onboardingStepProvider.notifier).state = OnboardingStep.orderRecipients;
        } else {
          _showValidationError(context, 'Please add at least one family member');
        }
        break;
      case OnboardingStep.orderRecipients:
        // Validate order recipients step
        if (_validateOrderRecipientsStep(ref)) {
          ref.read(onboardingStepProvider.notifier).state = OnboardingStep.addresses;
        } else {
          _showValidationError(context, 'Please add at least one order recipient');
        }
        break;
      case OnboardingStep.addresses:
        // Validate addresses step and complete onboarding
        if (_validateAddressesStep(ref)) {
          _completeOnboarding(context, ref);
        } else {
          _showValidationError(context, 'Please add at least one delivery address');
        }
        break;
    }
  }

  bool _validateFamilyMembersStep(WidgetRef ref) {
    final familyMembers = ref.read(familyMembersProvider);
    return familyMembers.isNotEmpty;
  }

  bool _validateOrderRecipientsStep(WidgetRef ref) {
    final orderRecipients = ref.read(orderRecipientsProvider);
    return orderRecipients.isNotEmpty;
  }

  bool _validateAddressesStep(WidgetRef ref) {
    final addresses = ref.read(addressesProvider);
    return addresses.isNotEmpty;
  }

  void _showValidationError(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
      ),
    );
  }

  void _completeOnboarding(BuildContext context, WidgetRef ref) {
    ref.read(onboardingCompletedProvider.notifier).state = true;
    ref.read(hasCompletedOnboardingProvider.notifier).state = true;
    
    // Navigate to subscription screen for new users
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (context.mounted) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => const SubscriptionScreen(isFromOnboarding: true),
          ),
        );
      }
    });
  }
}
