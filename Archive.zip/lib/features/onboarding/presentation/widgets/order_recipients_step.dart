import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../profile/application/profile_providers.dart';

class OrderRecipientsStep extends ConsumerWidget {
  const OrderRecipientsStep({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final familyMembers = ref.watch(familyMembersProvider);
    final orderRecipients = ref.watch(orderRecipientsProvider);

    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Text(
            'Order Recipients',
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          
          const SizedBox(height: 8),
          
          Text(
            'Choose who can receive gifts on your behalf. You can select family members or add new recipients.',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
              color: Colors.grey[600],
            ),
          ),
          
          const SizedBox(height: 32),
          
          // Add Recipient Button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => _showAddRecipientDialog(context),
              icon: const Icon(Icons.add),
              label: const Text('Add New Recipient'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.primary,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
          
          const SizedBox(height: 24),
          
          // Family Members Section
          if (familyMembers.isNotEmpty) ...[
            Text(
              'Select from Family Members',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 12),
            ...familyMembers.map((member) => _buildFamilyMemberCard(context, ref, member)),
            const SizedBox(height: 24),
          ],
          
          // Current Recipients Section
          if (orderRecipients.isNotEmpty) ...[
            Text(
              'Current Recipients',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: orderRecipients.length,
                itemBuilder: (context, index) {
                  final recipient = orderRecipients[index];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Theme.of(context).colorScheme.primary,
                        child: Text(
                          recipient.name[0].toUpperCase(),
                          style: const TextStyle(color: Colors.white),
                        ),
                      ),
                      title: Text(recipient.name),
                      subtitle: Text(recipient.phoneNumber),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          if (recipient.isDefault)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Theme.of(context).colorScheme.primary,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: const Text(
                                'DEFAULT',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          const SizedBox(width: 8),
                          IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () => _removeRecipient(ref, recipient.id),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ] else
            Expanded(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.person_add,
                      size: 80,
                      color: Colors.grey[300],
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'No recipients added yet',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Colors.grey[600],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Add at least one recipient to continue',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Colors.grey[500],
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildFamilyMemberCard(BuildContext context, WidgetRef ref, FamilyMember member) {
    final isSelected = _isFamilyMemberSelected(ref, member);
    
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: isSelected 
              ? Theme.of(context).colorScheme.primary 
              : Colors.grey[300],
          child: Text(
            member.name[0].toUpperCase(),
            style: TextStyle(
              color: isSelected ? Colors.white : Colors.grey[600],
            ),
          ),
        ),
        title: Text(member.name),
        subtitle: Text('${member.relation} • ${_formatDate(member.dateOfBirth)}'),
        trailing: isSelected
            ? Icon(
                Icons.check_circle,
                color: Theme.of(context).colorScheme.primary,
              )
            : const Icon(Icons.radio_button_unchecked),
        onTap: () => _toggleFamilyMemberSelection(ref, member),
      ),
    );
  }

  bool _isFamilyMemberSelected(WidgetRef ref, FamilyMember member) {
    final orderRecipients = ref.read(orderRecipientsProvider);
    return orderRecipients.any((recipient) => recipient.name == member.name);
  }

  void _toggleFamilyMemberSelection(WidgetRef ref, FamilyMember member) {
    final orderRecipients = ref.read(orderRecipientsProvider);
    final isSelected = orderRecipients.any((recipient) => recipient.name == member.name);
    
    if (isSelected) {
      // Remove from recipients
      final updatedRecipients = orderRecipients.where((recipient) => recipient.name != member.name).toList();
      ref.read(orderRecipientsProvider.notifier).state = updatedRecipients;
    } else {
      // Add to recipients
      final newRecipient = OrderRecipient(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: member.name,
        phoneNumber: '+92 300 0000000', // Default phone number
        isDefault: orderRecipients.isEmpty, // First one is default
      );
      ref.read(orderRecipientsProvider.notifier).state = [...orderRecipients, newRecipient];
    }
  }

  void _showAddRecipientDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => const AddRecipientDialog(),
    );
  }

  void _removeRecipient(WidgetRef ref, String id) {
    final recipients = ref.read(orderRecipientsProvider);
    final updatedRecipients = recipients.where((recipient) => recipient.id != id).toList();
    ref.read(orderRecipientsProvider.notifier).state = updatedRecipients;
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }
}

class AddRecipientDialog extends ConsumerStatefulWidget {
  const AddRecipientDialog({super.key});

  @override
  ConsumerState<AddRecipientDialog> createState() => _AddRecipientDialogState();
}

class _AddRecipientDialogState extends ConsumerState<AddRecipientDialog> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Add Order Recipient',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.close),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Form(
            key: _formKey,
            child: Column(
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    labelText: 'Recipient Name',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter the recipient name';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _phoneController,
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(
                    labelText: 'Phone Number',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    hintText: '+92 300 1234567',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter the phone number';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _addRecipient,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Theme.of(context).colorScheme.primary,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text('Add Recipient'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _addRecipient() {
    if (_formKey.currentState!.validate()) {
      final newRecipient = OrderRecipient(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: _nameController.text.trim(),
        phoneNumber: _phoneController.text.trim(),
        isDefault: false,
      );
      
      final recipients = ref.read(orderRecipientsProvider);
      ref.read(orderRecipientsProvider.notifier).state = [...recipients, newRecipient];
      
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${newRecipient.name} added as recipient'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }
}
