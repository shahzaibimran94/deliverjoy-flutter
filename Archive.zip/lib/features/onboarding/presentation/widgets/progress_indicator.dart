import 'package:flutter/material.dart';
import '../../application/onboarding_providers.dart';

class OnboardingProgressIndicator extends StatelessWidget {
  final OnboardingStep currentStep;

  const OnboardingProgressIndicator({
    super.key,
    required this.currentStep,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          // Progress bar
          Row(
            children: [
              _buildStepIndicator(context, 'Family Members', OnboardingStep.familyMembers),
              _buildConnector(context, OnboardingStep.familyMembers),
              _buildStepIndicator(context, 'Recipients', OnboardingStep.orderRecipients),
              _buildConnector(context, OnboardingStep.orderRecipients),
              _buildStepIndicator(context, 'Addresses', OnboardingStep.addresses),
            ],
          ),
          
          const SizedBox(height: 16),
          
          // Step title
          Text(
            _getStepTitle(currentStep),
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          
          const SizedBox(height: 8),
          
          // Step description
          Text(
            _getStepDescription(currentStep),
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
              color: Colors.grey[600],
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildStepIndicator(BuildContext context, String label, OnboardingStep step) {
    final isActive = currentStep == step;
    final isCompleted = _isStepCompleted(step);
    
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isCompleted
                  ? Theme.of(context).colorScheme.primary
                  : isActive
                      ? Theme.of(context).colorScheme.primary
                      : Colors.grey[300],
            ),
            child: isCompleted
                ? const Icon(
                    Icons.check,
                    color: Colors.white,
                    size: 20,
                  )
                : isActive
                    ? const Icon(
                        Icons.radio_button_checked,
                        color: Colors.white,
                        size: 20,
                      )
                    : Icon(
                        Icons.radio_button_unchecked,
                        color: Colors.grey[600],
                        size: 20,
                      ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
              color: isActive || isCompleted
                  ? Theme.of(context).colorScheme.primary
                  : Colors.grey[600],
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildConnector(BuildContext context, OnboardingStep fromStep) {
    final isCompleted = _isStepCompleted(fromStep);
    
    return Container(
      height: 2,
      width: 20,
      color: isCompleted
          ? Theme.of(context).colorScheme.primary
          : Colors.grey[300],
    );
  }

  bool _isStepCompleted(OnboardingStep step) {
    switch (step) {
      case OnboardingStep.familyMembers:
        return currentStep.index > OnboardingStep.familyMembers.index;
      case OnboardingStep.orderRecipients:
        return currentStep.index > OnboardingStep.orderRecipients.index;
      case OnboardingStep.addresses:
        return false; // Last step is never "completed" until onboarding is done
    }
  }

  String _getStepTitle(OnboardingStep step) {
    switch (step) {
      case OnboardingStep.familyMembers:
        return 'Add Family Members';
      case OnboardingStep.orderRecipients:
        return 'Set Order Recipients';
      case OnboardingStep.addresses:
        return 'Add Delivery Addresses';
    }
  }

  String _getStepDescription(OnboardingStep step) {
    switch (step) {
      case OnboardingStep.familyMembers:
        return 'Add at least one family member to get started';
      case OnboardingStep.orderRecipients:
        return 'Choose who can receive gifts on your behalf';
      case OnboardingStep.addresses:
        return 'Add delivery addresses for gift orders';
    }
  }
}
