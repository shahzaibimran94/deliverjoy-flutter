import 'package:flutter_riverpod/flutter_riverpod.dart';

// Payment processing state
final paymentProcessingProvider = StateProvider.autoDispose<bool>((ref) => false);

// Process payment
Future<bool> processPayment(WidgetRef ref) async {
  ref.read(paymentProcessingProvider.notifier).state = true;
  
  // Simulate payment processing
  await Future.delayed(const Duration(seconds: 3));
  
  ref.read(paymentProcessingProvider.notifier).state = false;
  
  // In a real app, this would call a payment API
  return true; // Simulate successful payment
}
