import 'package:flutter_riverpod/flutter_riverpod.dart';

// Subscription plan enum
enum SubscriptionPlan {
  free,
  pro,
}

// Subscription plan model
class SubscriptionPlanModel {
  final SubscriptionPlan plan;
  final String name;
  final String description;
  final double price;
  final String priceUnit;
  final List<String> features;
  final bool isPopular;

  const SubscriptionPlanModel({
    required this.plan,
    required this.name,
    required this.description,
    required this.price,
    required this.priceUnit,
    required this.features,
    this.isPopular = false,
  });
}

// Subscription state providers
final selectedSubscriptionProvider = StateProvider.autoDispose<SubscriptionPlan>((ref) => SubscriptionPlan.free);

final subscriptionPlansProvider = Provider.autoDispose<List<SubscriptionPlanModel>>((ref) => [
  const SubscriptionPlanModel(
    plan: SubscriptionPlan.free,
    name: 'Free',
    description: 'Basic features for casual users',
    price: 0,
    priceUnit: 'month',
    features: [
      'Basic delivery tracking',
      'Standard delivery rates',
      '1 custom order per month',
      'Basic customer support',
    ],
  ),
  const SubscriptionPlanModel(
    plan: SubscriptionPlan.pro,
    name: 'Pro',
    description: 'Premium features for frequent users',
    price: 9.99,
    priceUnit: 'month',
    features: [
      'Up to 50% cheaper delivery rates',
      'Unlimited custom orders',
      'Priority customer support',
      'Advanced delivery tracking',
      'Exclusive pro member discounts',
      'Early access to new features',
      'Free delivery on orders over \$25',
    ],
    isPopular: true,
  ),
]);

// User subscription status
final userSubscriptionProvider = StateProvider.autoDispose<SubscriptionPlan>((ref) => SubscriptionPlan.free);

// Check if user is pro member
final isProMemberProvider = Provider.autoDispose<bool>((ref) {
  final subscription = ref.watch(userSubscriptionProvider);
  return subscription == SubscriptionPlan.pro;
});

// Subscription management functions
void updateSubscription(WidgetRef ref, SubscriptionPlan plan) {
  ref.read(userSubscriptionProvider.notifier).state = plan;
}

void selectSubscription(WidgetRef ref, SubscriptionPlan plan) {
  ref.read(selectedSubscriptionProvider.notifier).state = plan;
}
