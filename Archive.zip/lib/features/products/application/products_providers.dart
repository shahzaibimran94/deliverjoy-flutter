import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

// Categories
final categoriesProvider = Provider<List<Category>>((ref) => [
  const Category(id: 'all', name: 'All', icon: Icons.grid_view),
  const Category(id: 'gift_boxes', name: 'Gift Boxes', icon: Icons.card_giftcard),
  const Category(id: 'clothes', name: 'Clothes', icon: Icons.checkroom),
  const Category(id: 'cakes', name: 'Cakes', icon: Icons.cake),
  const Category(id: 'flowers', name: 'Flowers', icon: Icons.local_florist),
  const Category(id: 'accessories', name: 'Accessories', icon: Icons.watch),
  const Category(id: 'toys', name: 'Toys', icon: Icons.toys),
  const Category(id: 'electronics', name: 'Electronics', icon: Icons.phone_android),
]);

// Selected category
final selectedCategoryProvider = StateProvider.autoDispose<String>((ref) => 'all');

// Products
final allProductsProvider = Provider<List<ProductModel>>((ref) => [
  // Gift Boxes
  const ProductModel(
    id: '1',
    name: 'Luxury Gift Box',
    imageUrl: 'https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=300',
    price: 79.99,
    oldPrice: 99.99,
    category: 'gift_boxes',
  ),
  const ProductModel(
    id: '2',
    name: 'Premium Gift Set',
    imageUrl: 'https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=300',
    price: 129.99,
    oldPrice: 159.99,
    category: 'gift_boxes',
  ),
  
  // Clothes
  const ProductModel(
    id: '3',
    name: 'Silk Scarf',
    imageUrl: 'https://images.unsplash.com/photo-1611937761055-7b6ccd8be8f6?w=300',
    price: 24.50,
    oldPrice: 29.99,
    category: 'clothes',
  ),
  const ProductModel(
    id: '4',
    name: 'Designer T-Shirt',
    imageUrl: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300',
    price: 39.99,
    oldPrice: 49.99,
    category: 'clothes',
  ),
  
  // Cakes
  const ProductModel(
    id: '5',
    name: 'Custom Photo Cake',
    imageUrl: 'https://images.unsplash.com/photo-1519869325930-281384150729?w=300',
    price: 34.99,
    oldPrice: 44.99,
    category: 'cakes',
  ),
  const ProductModel(
    id: '6',
    name: 'Chocolate Delight',
    imageUrl: 'https://images.unsplash.com/photo-1548907040-4a1b3e06c6ab?w=300',
    price: 19.99,
    oldPrice: 25.99,
    category: 'cakes',
  ),
  
  // Flowers
  const ProductModel(
    id: '7',
    name: 'Velvet Rose Bouquet',
    imageUrl: 'https://images.unsplash.com/photo-1509043759401-136742328bb3?w=300',
    price: 49.99,
    oldPrice: 59.99,
    category: 'flowers',
  ),
  const ProductModel(
    id: '8',
    name: 'Mixed Flower Arrangement',
    imageUrl: 'https://images.unsplash.com/photo-1518199266791-5375a83190b7?w=300',
    price: 35.99,
    oldPrice: 45.99,
    category: 'flowers',
  ),
  
  // Accessories
  const ProductModel(
    id: '9',
    name: 'Designer Watch',
    imageUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300',
    price: 199.99,
    oldPrice: 249.99,
    category: 'accessories',
  ),
  const ProductModel(
    id: '10',
    name: 'Leather Wallet',
    imageUrl: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=300',
    price: 89.99,
    oldPrice: 119.99,
    category: 'accessories',
  ),
  
  // Toys
  const ProductModel(
    id: '11',
    name: 'Educational Toy Set',
    imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=300',
    price: 45.99,
    oldPrice: 59.99,
    category: 'toys',
  ),
  const ProductModel(
    id: '12',
    name: 'Remote Control Car',
    imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=300',
    price: 79.99,
    oldPrice: 99.99,
    category: 'toys',
  ),
  
  // Electronics
  const ProductModel(
    id: '13',
    name: 'Wireless Headphones',
    imageUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300',
    price: 149.99,
    oldPrice: 199.99,
    category: 'electronics',
  ),
  const ProductModel(
    id: '14',
    name: 'Smart Speaker',
    imageUrl: 'https://images.unsplash.com/photo-1543512214-318c7553f226?w=300',
    price: 89.99,
    oldPrice: 129.99,
    category: 'electronics',
  ),
]);

// Filtered products based on selected category
final filteredProductsProvider = Provider.autoDispose<List<ProductModel>>((ref) {
  final products = ref.watch(allProductsProvider);
  final selectedCategory = ref.watch(selectedCategoryProvider);
  
  if (selectedCategory == 'all') {
    return products;
  }
  
  return products.where((product) => product.category == selectedCategory).toList();
});

// Search query
final searchQueryProvider = StateProvider.autoDispose<String>((ref) => '');

// Search results
final searchResultsProvider = Provider.autoDispose<List<ProductModel>>((ref) {
  final products = ref.watch(filteredProductsProvider);
  final query = ref.watch(searchQueryProvider);
  
  if (query.isEmpty) {
    return products;
  }
  
  return products.where((product) => 
    product.name.toLowerCase().contains(query.toLowerCase())
  ).toList();
});

// Data models
class Category {
  final String id;
  final String name;
  final IconData icon;
  
  const Category({
    required this.id,
    required this.name,
    required this.icon,
  });
}

class ProductModel {
  final String id;
  final String name;
  final String imageUrl;
  final double price;
  final double oldPrice;
  final String category;
  
  const ProductModel({
    required this.id,
    required this.name,
    required this.imageUrl,
    required this.price,
    required this.oldPrice,
    required this.category,
  });
}
