import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class SearchBar extends StatefulWidget {
  const SearchBar({super.key});

  @override
  State<SearchBar> createState() => _SearchBarState();
}

class _SearchBarState extends State<SearchBar> {
  final TextEditingController _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _performSearch() async {
    final query = _controller.text.trim();
    if (query.isEmpty) {
      if (mounted) context.push('/chat');
      return;
    }

    // Navigate to chat with the query - let chat screen handle the search
    if (mounted) {
      context.push('/chat', extra: query);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: TextField(
        controller: _controller,
        decoration: InputDecoration(
          hintText: 'Search gifts, categories, occasions',
          prefixIcon: const Icon(Icons.search),
          suffixIcon: IconButton(
            onPressed: _performSearch,
            icon: const Icon(Icons.arrow_forward),
          ),
          filled: true,
          fillColor: Colors.grey[100],
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          contentPadding: const EdgeInsets.symmetric(vertical: 14),
        ),
        textInputAction: TextInputAction.search,
        onSubmitted: (_) => _performSearch(),
        onTap: () {
          // If empty, go to chat
          if (_controller.text.isEmpty && mounted) {
            context.push('/chat');
          }
        },
      ),
    );
  }
}


