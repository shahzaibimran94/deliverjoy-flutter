import 'package:flutter/material.dart';
import 'package:deliverjoy_flutter/features/home/presentation/widgets/header.dart';
import 'package:deliverjoy_flutter/features/home/presentation/widgets/search_bar.dart' as search_widget;
import 'package:deliverjoy_flutter/features/home/presentation/widgets/event_carousel.dart';
import 'package:deliverjoy_flutter/features/home/presentation/widgets/category_chips.dart';
import 'package:deliverjoy_flutter/features/home/presentation/widgets/trending_products.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(child: Header()),
          SliverToBoxAdapter(child: search_widget.SearchBar()),
          const SliverToBoxAdapter(child: SizedBox(height: 12)),
          SliverToBoxAdapter(child: EventCarousel()),
          const SliverToBoxAdapter(child: SizedBox(height: 16)),
          SliverToBoxAdapter(child: CategoryChips()),
          const SliverToBoxAdapter(child: SizedBox(height: 16)),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Text(
                'Trending products',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 8)),
          SliverToBoxAdapter(child: TrendingProducts()),
          const SliverPadding(padding: EdgeInsets.only(bottom: 24)),
        ],
      ),
    );
  }
}


