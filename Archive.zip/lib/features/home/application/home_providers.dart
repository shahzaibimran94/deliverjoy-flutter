import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:deliverjoy_flutter/core/constants/app_constants.dart';

// Greeting provider
final greetingProvider = Provider<String>((ref) {
  return 'Good evening\n${AppConstants.defaultUserName}';
});

// Categories
final categoriesProvider = Provider<List<(IconData, String)>>((ref) {
  return const [
    (Icons.card_giftcard, 'Gift boxes'),
    (Icons.checkroom, 'Clothes'),
    (Icons.cake, 'Cakes'),
    (Icons.local_florist, 'Flowers'),
    (Icons.watch, 'Accessories'),
    (Icons.toys, 'Toys'),
  ];
});

// Event slides model
class EventSlide {
  final String title;
  final String subtitle;
  final String imageUrl;
  final Color accent;
  const EventSlide({required this.title, required this.subtitle, required this.imageUrl, required this.accent});
}

final eventSlidesProvider = Provider<List<EventSlide>>((ref) {
  return const [
    EventSlide(
      title: "Mother's Day",
      subtitle: 'Make her smile with something special',
      imageUrl: 'https://images.unsplash.com/photo-1523289333742-be1143f6b766?q=80&w=1200',
      accent: Color(0xFFFFE2E5),
    ),
    EventSlide(
      title: "Valentine's Day",
      subtitle: 'Say it with a heartfelt surprise',
      imageUrl: 'https://images.unsplash.com/photo-1518199266791-5375a83190b7?q=80&w=1200',
      accent: Color(0xFFFFE4EC),
    ),
    EventSlide(
      title: "Father's Day",
      subtitle: 'For his timeless support',
      imageUrl: 'https://images.unsplash.com/photo-1521185496955-15097b20c5fe?q=80&w=1200',
      accent: Color(0xFFEFF6FF),
    ),
  ];
});

// Product
class ProductModel {
  final String id;
  final String name;
  final String imageUrl;
  final double price;
  final double oldPrice;
  const ProductModel({required this.id, required this.name, required this.imageUrl, required this.price, required this.oldPrice});
}

final trendingProductsProvider = Provider<List<ProductModel>>((ref) {
  return const [
    ProductModel(
      id: '1',
      name: 'Velvet Rose Bouquet',
      imageUrl: 'https://images.unsplash.com/photo-1509043759401-136742328bb3?q=80&w=1200',
      price: 49.99,
      oldPrice: 59.99,
    ),
    ProductModel(
      id: '2',
      name: 'Custom Photo Cake',
      imageUrl: 'https://images.unsplash.com/photo-1519869325930-281384150729?q=80&w=1200',
      price: 34.99,
      oldPrice: 44.99,
    ),
    ProductModel(
      id: '3',
      name: 'Silk Scarf',
      imageUrl: 'https://images.unsplash.com/photo-1611937761055-7b6ccd8be8f6?q=80&w=1200',
      price: 24.50,
      oldPrice: 29.99,
    ),
    ProductModel(
      id: '4',
      name: 'Luxury Chocolate Box',
      imageUrl: 'https://images.unsplash.com/photo-1548907040-4a1b3e06c6ab?q=80&w=1200',
      price: 19.99,
      oldPrice: 25.99,
    ),
  ];
});


