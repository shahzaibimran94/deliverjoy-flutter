import 'package:flutter_riverpod/flutter_riverpod.dart';

// Authentication state
final authStateProvider = StateProvider.autoDispose<AuthState>((ref) => AuthState.initial);

// User data
final userProvider = StateProvider.autoDispose<User?>((ref) => null);

// Onboarding completion state
final hasCompletedOnboardingProvider = StateProvider.autoDispose<bool>((ref) => false);

// Loading states
final isLoadingProvider = StateProvider.autoDispose<bool>((ref) => false);
final isSigningUpProvider = StateProvider.autoDispose<bool>((ref) => false);
final isSigningInProvider = StateProvider.autoDispose<bool>((ref) => false);
final isResettingPasswordProvider = StateProvider.autoDispose<bool>((ref) => false);

// Authentication methods
Future<bool> signInWithEmail(WidgetRef ref, String email, String password) async {
  ref.read(isSigningInProvider.notifier).state = true;
  
  try {
    // Simulate API call
    await Future.delayed(const Duration(seconds: 2));
    
    // Mock authentication - in real app, this would call your auth service
    if (email.isNotEmpty && password.isNotEmpty) {
      final user = User(
        id: 'user_${DateTime.now().millisecondsSinceEpoch}',
        email: email,
        name: email.split('@')[0],
        avatarUrl: null,
      );
      
      ref.read(userProvider.notifier).state = user;
      ref.read(authStateProvider.notifier).state = AuthState.authenticated;
      ref.read(hasCompletedOnboardingProvider.notifier).state = true; // Existing user has completed onboarding
      
      ref.read(isSigningInProvider.notifier).state = false;
      return true;
    } else {
      ref.read(isSigningInProvider.notifier).state = false;
      return false;
    }
  } catch (e) {
    ref.read(isSigningInProvider.notifier).state = false;
    return false;
  }
}

Future<bool> signUpWithEmail(WidgetRef ref, String email, String password, String name) async {
  ref.read(isSigningUpProvider.notifier).state = true;
  
  try {
    // Simulate API call
    await Future.delayed(const Duration(seconds: 2));
    
    // Mock authentication - in real app, this would call your auth service
        if (email.isNotEmpty && password.isNotEmpty && name.isNotEmpty) {
          final user = User(
            id: 'user_${DateTime.now().millisecondsSinceEpoch}',
            email: email,
            name: name,
            avatarUrl: null,
          );

          ref.read(userProvider.notifier).state = user;
          ref.read(authStateProvider.notifier).state = AuthState.authenticated;
          ref.read(hasCompletedOnboardingProvider.notifier).state = false; // New user needs onboarding

          ref.read(isSigningUpProvider.notifier).state = false;
          return true;
    } else {
      ref.read(isSigningUpProvider.notifier).state = false;
      return false;
    }
  } catch (e) {
    ref.read(isSigningUpProvider.notifier).state = false;
    return false;
  }
}

Future<bool> signInWithGoogle(WidgetRef ref) async {
  ref.read(isSigningInProvider.notifier).state = true;
  
  try {
    // Simulate Google Sign-In
    await Future.delayed(const Duration(seconds: 2));
    
        final user = User(
          id: 'google_user_${DateTime.now().millisecondsSinceEpoch}',
          email: 'user@gmail.com',
          name: 'Google User',
          avatarUrl: 'https://via.placeholder.com/150',
        );

        ref.read(userProvider.notifier).state = user;
        ref.read(authStateProvider.notifier).state = AuthState.authenticated;
        ref.read(hasCompletedOnboardingProvider.notifier).state = true; // Existing user has completed onboarding
    
    ref.read(isSigningInProvider.notifier).state = false;
    return true;
  } catch (e) {
    ref.read(isSigningInProvider.notifier).state = false;
    return false;
  }
}

Future<bool> signInWithApple(WidgetRef ref) async {
  ref.read(isSigningInProvider.notifier).state = true;
  
  try {
    // Simulate Apple Sign-In
    await Future.delayed(const Duration(seconds: 2));
    
        final user = User(
          id: 'apple_user_${DateTime.now().millisecondsSinceEpoch}',
          email: 'user@icloud.com',
          name: 'Apple User',
          avatarUrl: null,
        );

        ref.read(userProvider.notifier).state = user;
        ref.read(authStateProvider.notifier).state = AuthState.authenticated;
        ref.read(hasCompletedOnboardingProvider.notifier).state = true; // Existing user has completed onboarding
    
    ref.read(isSigningInProvider.notifier).state = false;
    return true;
  } catch (e) {
    ref.read(isSigningInProvider.notifier).state = false;
    return false;
  }
}

Future<bool> resetPassword(WidgetRef ref, String email) async {
  ref.read(isResettingPasswordProvider.notifier).state = true;
  
  try {
    // Simulate password reset
    await Future.delayed(const Duration(seconds: 2));
    
    ref.read(isResettingPasswordProvider.notifier).state = false;
    return email.isNotEmpty;
  } catch (e) {
    ref.read(isResettingPasswordProvider.notifier).state = false;
    return false;
  }
}

void signOut(WidgetRef ref) {
  ref.read(userProvider.notifier).state = null;
  ref.read(authStateProvider.notifier).state = AuthState.unauthenticated;
}

  void skipLogin(WidgetRef ref) {
    // Create a guest user for skipping login
    final guestUser = User(
      id: 'guest_user_${DateTime.now().millisecondsSinceEpoch}',
      email: 'guest@deliverjoy.com',
      name: 'Guest User',
      avatarUrl: null,
    );

    ref.read(userProvider.notifier).state = guestUser;
    ref.read(authStateProvider.notifier).state = AuthState.authenticated;
    ref.read(hasCompletedOnboardingProvider.notifier).state = true; // Guest user skips onboarding
  }

// Data models
enum AuthState {
  initial,
  authenticated,
  unauthenticated,
}

class User {
  final String id;
  final String email;
  final String name;
  final String? avatarUrl;
  
  const User({
    required this.id,
    required this.email,
    required this.name,
    this.avatarUrl,
  });
}
