import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../application/auth_providers.dart';
import '../../onboarding/application/onboarding_providers.dart';

class AuthGuard extends ConsumerWidget {
  final Widget child;
  
  const AuthGuard({
    super.key,
    required this.child,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authStateProvider);
    final user = ref.watch(userProvider);
    final hasCompletedOnboarding = ref.watch(hasCompletedOnboardingProvider);
    
    // If user is authenticated, show the protected content
    if (authState == AuthState.authenticated && user != null) {
      return child;
    }
    
    // If not authenticated, redirect to login
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (context.mounted) {
        context.go('/login');
      }
    });
    
    // Show loading while redirecting
    return const Scaffold(
      body: Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}

class GuestGuard extends ConsumerWidget {
  final Widget child;
  
  const GuestGuard({
    super.key,
    required this.child,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authStateProvider);
    final user = ref.watch(userProvider);
    
    // If user is not authenticated, show the guest content
    if (authState == AuthState.unauthenticated || user == null) {
      return child;
    }
    
    // If authenticated, redirect to home
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (context.mounted) {
        context.go('/home');
      }
    });
    
    // Show loading while redirecting
    return const Scaffold(
      body: Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}
