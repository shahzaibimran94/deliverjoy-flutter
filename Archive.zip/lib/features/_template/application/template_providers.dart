import 'package:flutter_riverpod/flutter_riverpod.dart';

// Example provider for template feature
final templateDataProvider = Provider<String>((ref) {
  return 'Template data';
});

// Example state notifier for template feature
class TemplateNotifier extends StateNotifier<String> {
  TemplateNotifier() : super('Initial state');

  void updateState(String newState) {
    state = newState;
  }
}

final templateNotifierProvider = StateNotifierProvider<TemplateNotifier, String>((ref) {
  return TemplateNotifier();
});
