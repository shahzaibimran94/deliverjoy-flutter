# Template Feature

This is a template for creating new features in the DeliverJoy app.

## Structure

```
lib/features/_template/
├── application/
│   └── template_providers.dart    # Riverpod providers and state management
├── domain/
│   └── models/
│       └── template_model.dart    # Data models with Freezed
├── infrastructure/
│   └── repositories/
│       └── template_repository.dart # Repository implementation
└── presentation/
    └── screens/
        └── template_screen.dart   # UI screens
```

## Usage

1. Copy the `_template` folder
2. Rename it to your feature name (e.g., `products`, `orders`, `profile`)
3. Update all file names and class names to match your feature
4. Implement your business logic in the appropriate layers

## Layers

- **Presentation**: UI components, screens, widgets
- **Application**: State management, providers, use cases
- **Domain**: Business logic, models, entities
- **Infrastructure**: Data sources, repositories, external services

## Dependencies

- `flutter_riverpod` for state management
- `freezed` for immutable data classes
- `json_annotation` for JSON serialization
- `dio` for HTTP requests
