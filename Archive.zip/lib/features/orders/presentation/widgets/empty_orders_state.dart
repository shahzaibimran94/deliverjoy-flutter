import 'package:flutter/material.dart';
import '../../application/order_providers.dart';

class EmptyOrdersState extends StatelessWidget {
  final OrderTab tab;

  const EmptyOrdersState({
    super.key,
    required this.tab,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                color: Colors.grey[100],
                shape: BoxShape.circle,
              ),
              child: Icon(
                tab == OrderTab.current ? Icons.shopping_bag_outlined : Icons.history,
                size: 60,
                color: Colors.grey[400],
              ),
            ),
            const SizedBox(height: 24),
            Text(
              tab == OrderTab.current ? 'No Current Orders' : 'No Past Orders',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: Colors.grey[700],
              ),
            ),
            const SizedBox(height: 12),
            Text(
              tab == OrderTab.current
                  ? 'Your current orders will appear here.\nStart shopping to place your first order!'
                  : 'Your completed orders will appear here.\nOrders you\'ve received will show up in this tab.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.grey[600],
                height: 1.5,
              ),
            ),
            const SizedBox(height: 32),
            if (tab == OrderTab.current)
              ElevatedButton.icon(
                onPressed: () {
                  // Navigate to home screen
                  Navigator.of(context).pop();
                },
                icon: const Icon(Icons.shopping_cart),
                label: const Text('Start Shopping'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Theme.of(context).colorScheme.primary,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
