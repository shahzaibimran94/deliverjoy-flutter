import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../application/order_providers.dart';
import 'widgets/order_card.dart';
import 'widgets/empty_orders_state.dart';

class OrdersScreen extends ConsumerWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedTab = ref.watch(selectedOrderTabProvider);
    final orders = ref.watch(filteredOrdersProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Orders'),
        backgroundColor: Theme.of(context).colorScheme.surface,
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.grey[100],
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Expanded(
                  child: _buildTabButton(
                    context,
                    ref,
                    OrderTab.current,
                    'Current',
                    selectedTab == OrderTab.current,
                  ),
                ),
                Expanded(
                  child: _buildTabButton(
                    context,
                    ref,
                    OrderTab.past,
                    'Past',
                    selectedTab == OrderTab.past,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      body: orders.isEmpty
          ? EmptyOrdersState(tab: selectedTab)
          : RefreshIndicator(
              onRefresh: () async {
                // In a real app, this would refresh orders from API
                await Future.delayed(const Duration(seconds: 1));
              },
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(vertical: 8),
                itemCount: orders.length,
                itemBuilder: (context, index) {
                  final order = orders[index];
                  return OrderCard(order: order);
                },
              ),
            ),
    );
  }

  Widget _buildTabButton(
    BuildContext context,
    WidgetRef ref,
    OrderTab tab,
    String label,
    bool isSelected,
  ) {
    return GestureDetector(
      onTap: () {
        ref.read(selectedOrderTabProvider.notifier).state = tab;
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.1),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ]
              : null,
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
            color: isSelected
                ? Theme.of(context).colorScheme.primary
                : Colors.grey[600],
            fontSize: 16,
          ),
        ),
      ),
    );
  }
}


