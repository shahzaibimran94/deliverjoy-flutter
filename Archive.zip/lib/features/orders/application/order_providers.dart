import 'package:flutter_riverpod/flutter_riverpod.dart';

// Order state
final selectedOrderTabProvider = StateProvider.autoDispose<OrderTab>((ref) => OrderTab.current);
final ordersProvider = StateProvider.autoDispose<List<Order>>((ref) => _getMockOrders());

// Filtered orders based on selected tab
final filteredOrdersProvider = Provider.autoDispose<List<Order>>((ref) {
  final orders = ref.watch(ordersProvider);
  final selectedTab = ref.watch(selectedOrderTabProvider);
  
  switch (selectedTab) {
    case OrderTab.current:
      return orders.where((order) => order.status != OrderStatus.delivered).toList();
    case OrderTab.past:
      return orders.where((order) => order.status == OrderStatus.delivered).toList();
  }
});

// Mock orders data
List<Order> _getMockOrders() {
  return [
    Order(
      id: 'ORD-001',
      items: [
        OrderItem(
          id: '1',
          name: 'Mother\'s Day Gift Box',
          price: 49.99,
          quantity: 1,
          imageUrl: 'https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=150',
        ),
        OrderItem(
          id: '2',
          name: 'Chocolate Collection',
          price: 24.99,
          quantity: 2,
          imageUrl: 'https://images.unsplash.com/photo-1511381939415-e44015466834?w=150',
        ),
      ],
      totalAmount: 99.97,
      status: OrderStatus.processing,
      orderDate: DateTime.now().subtract(const Duration(days: 2)),
      estimatedDelivery: DateTime.now().add(const Duration(days: 3)),
    ),
    Order(
      id: 'ORD-002',
      items: [
        OrderItem(
          id: '3',
          name: 'Valentine\'s Day Special',
          price: 79.99,
          quantity: 1,
          imageUrl: 'https://images.unsplash.com/photo-1518199266791-5375a83190b7?w=150',
        ),
      ],
      totalAmount: 79.99,
      status: OrderStatus.shipped,
      orderDate: DateTime.now().subtract(const Duration(days: 5)),
      estimatedDelivery: DateTime.now().add(const Duration(days: 1)),
      trackingNumber: 'TRK123456789',
    ),
    Order(
      id: 'ORD-003',
      items: [
        OrderItem(
          id: '4',
          name: 'Father\'s Day Tools',
          price: 129.99,
          quantity: 1,
          imageUrl: 'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=150',
        ),
        OrderItem(
          id: '5',
          name: 'Custom Gift Wrapping',
          price: 9.99,
          quantity: 1,
          imageUrl: 'https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=150',
        ),
      ],
      totalAmount: 139.98,
      status: OrderStatus.delivered,
      orderDate: DateTime.now().subtract(const Duration(days: 15)),
      deliveredDate: DateTime.now().subtract(const Duration(days: 3)),
    ),
    Order(
      id: 'ORD-004',
      items: [
        OrderItem(
          id: '6',
          name: 'Custom Order - Amazon Product',
          price: 99.99,
          quantity: 1,
          imageUrl: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=150',
        ),
      ],
      totalAmount: 99.99,
      status: OrderStatus.delivered,
      orderDate: DateTime.now().subtract(const Duration(days: 30)),
      deliveredDate: DateTime.now().subtract(const Duration(days: 20)),
    ),
  ];
}

enum OrderTab { current, past }

class Order {
  final String id;
  final List<OrderItem> items;
  final double totalAmount;
  final OrderStatus status;
  final DateTime orderDate;
  final DateTime? estimatedDelivery;
  final DateTime? deliveredDate;
  final String? trackingNumber;
  final String? notes;

  const Order({
    required this.id,
    required this.items,
    required this.totalAmount,
    required this.status,
    required this.orderDate,
    this.estimatedDelivery,
    this.deliveredDate,
    this.trackingNumber,
    this.notes,
  });
}

class OrderItem {
  final String id;
  final String name;
  final double price;
  final int quantity;
  final String imageUrl;

  const OrderItem({
    required this.id,
    required this.name,
    required this.price,
    required this.quantity,
    required this.imageUrl,
  });
}

enum OrderStatus {
  pending,
  confirmed,
  processing,
  shipped,
  delivered,
  cancelled,
}

extension OrderStatusExtension on OrderStatus {
  String get displayName {
    switch (this) {
      case OrderStatus.pending:
        return 'Pending';
      case OrderStatus.confirmed:
        return 'Confirmed';
      case OrderStatus.processing:
        return 'Processing';
      case OrderStatus.shipped:
        return 'Shipped';
      case OrderStatus.delivered:
        return 'Delivered';
      case OrderStatus.cancelled:
        return 'Cancelled';
    }
  }

  String get description {
    switch (this) {
      case OrderStatus.pending:
        return 'Your order is being reviewed';
      case OrderStatus.confirmed:
        return 'Order confirmed, preparing items';
      case OrderStatus.processing:
        return 'Items are being prepared';
      case OrderStatus.shipped:
        return 'Order is on its way';
      case OrderStatus.delivered:
        return 'Order has been delivered';
      case OrderStatus.cancelled:
        return 'Order has been cancelled';
    }
  }
}
